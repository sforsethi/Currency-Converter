//
//  NiceLogger.h
//  NiceLogger
//
//  Created by Raghav Sethi on 31/05/22.
//

#import <Foundation/Foundation.h>

//! Project version number for NiceLogger.
FOUNDATION_EXPORT double NiceLoggerVersionNumber;

//! Project version string for NiceLogger.
FOUNDATION_EXPORT const unsigned char NiceLoggerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <NiceLogger/PublicHeader.h>


